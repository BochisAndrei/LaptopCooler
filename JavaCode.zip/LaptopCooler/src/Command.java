
public interface Command {
    void executa();
}
