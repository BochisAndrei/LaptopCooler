
public class Main {
	public static void main(String[] args) {
		@SuppressWarnings("unused")
		GestiuneTemp g=new GestiuneTemp();
		
		}
}

